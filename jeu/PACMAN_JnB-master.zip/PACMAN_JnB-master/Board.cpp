#include "Board.h"
#include <vector>


// Constructeur
Board::Board(int width, int height) {
    // Initialiser la matrice avec des tuiles vides (0)
    tiles.resize(height);
    for (int i = 0; i < height; ++i) {
        tiles[i].resize(width, 0);
    }
}

// M�thode pour acc�der � la valeur d'une tuile � une position donn�e
int Board::getTile(int x, int y) const {
    return tiles[y][x];
}

// M�thode pour d�finir la valeur d'une tuile � une position donn�e
void Board::setTile(int x, int y, int value) {
    tiles[y][x] = value;
}

// M�thode pour obtenir la largeur de la carte
int Board::getWidth() const {
    return tiles.empty() ? 0 : tiles[0].size();
}

// M�thode pour obtenir la hauteur de la carte
int Board::getHeight() const {
    return tiles.size();
}
