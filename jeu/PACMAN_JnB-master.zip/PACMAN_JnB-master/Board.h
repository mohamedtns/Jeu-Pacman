#ifndef BOARD_H
#define BOARD_H

#include <vector>

class Board {
private:
    std::vector<std::vector<int>> tiles; // Matrice de tuiles

public:
    // Constructeur
    Board(int width, int height);

    // M�thode pour acc�der � la valeur d'une tuile � une position donn�e
    int getTile(int x, int y) const;

    // M�thode pour d�finir la valeur d'une tuile � une position donn�e
    void setTile(int x, int y, int value);

    // M�thode pour obtenir la largeur de la carte
    int getWidth() const;

    // M�thode pour obtenir la hauteur de la carte
    int getHeight() const;
};

#endif // BOARD_H
