#include <SFML/Graphics.hpp>
#include <vector>
#include "carte.h"
#include "Board.h"
int main()
{
    // Cr�ation de la fen�tre SFML
    sf::RenderWindow window(sf::VideoMode(1000, 1000), "Fen�tre noire SFML");

    // Cr�ation d'un objet Board de taille 30x30
    Board board(30, 30);


    Carte carte("Sprite/tilemap.png","Sprite/Pacman_carte.txt");
        std::vector<std::vector<int>> tileMap = createTileMapFromFile("Sprite/Pacman_carte.txt");
    // Boucle principale
    while (window.isOpen())
    {
        // V�rifier tous les �v�nements
        sf::Event event;
        while (window.pollEvent(event))
        {
            // Fermer la fen�tre si l'utilisateur le demande
            if (event.type == sf::Event::Closed)
                window.close();
        }

        // Effacer l'�cran avec une couleur noire
        window.clear(sf::Color::Black);
        carte.dessiner(window);

        // Dessiner ici votre plateau de jeu en utilisant les valeurs de la matrice board

        // Afficher le contenu de la fen�tre
        window.display();
    }

    return 0;
}
